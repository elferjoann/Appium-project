import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;

public class CreateSession {

    public static AppiumDriver initializeDriver(String platformName) throws Exception {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("platformName", platformName);
   //     caps.setCapability("newCommandTimeout", 300);

        URL url = new URL("http://0.0.0.0:4723");

        switch(platformName){
            case "Android":
            	caps.setCapability("deviceName", "a22x");
    			caps.setCapability("udid", "R9WT20APN3T");
    			caps.setCapability("platformVersion", "11");
    			caps.setCapability("appPackage", "com.airbnb.android");
    			caps.setCapability("appActivity", "com.airbnb.android.feat.homescreen.HomeActivity");
    			caps.setCapability("automationName", "UiAutomator2");
                return new AndroidDriver(url, caps);
            default:
                throw new Exception("invalid platform");
        }
    }
}
