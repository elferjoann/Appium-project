import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Interaction;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.RemoteWebElement;
import java.time.Duration;
import java.util.Arrays;

public class AppiumTest {

    public static void main(String[] args) throws Exception {
        AppiumDriver driver = CreateSession.initializeDriver("Android");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

			System.out.println("Automated Application Started");
			driver.findElement(By.id("com.airbnb.android:id/start_button")).click();
			driver.findElement(By.xpath("//android.widget.TextView[@text=\"Buscar destinos\"]")).click();
			driver.findElement(By.id("com.airbnb.android:id/input_bar_input")).sendKeys("Cusco");
			driver.findElement(By.xpath("(//android.widget.ImageView[@resource-id=\"com.airbnb.android:id/icon\"])[1]")).click();
		    driver.findElement(By.id("com.airbnb.android:id/all_other_search_components")).click();
		    driver.findElement(By.xpath("//android.view.ViewGroup[@resource-id=\"com.airbnb.android:id/stays_when_panel_compose\"]/android.view.View/android.view.View/android.view.View[2]")).click();
		    
		    PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		    Point tapPoint = new Point(672, 1317);
		    Sequence tap = new Sequence(finger, 1);
		    tap.addAction(finger.createPointerMove(Duration.ofMillis(0),
		        PointerInput.Origin.viewport(), tapPoint.x, tapPoint.y));
		    tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		    tap.addAction(new Pause(finger, Duration.ofMillis(50)));
		    tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		    driver.perform(Arrays.asList(tap));
		    
		    driver.findElement(By.xpath("//android.view.ViewGroup[@resource-id=\"com.airbnb.android:id/stays_when_panel_compose\"]/android.view.View/android.view.View/android.view.View[2]")).click();
		    PointerInput finger2 = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		    Point tapPoint2 = new Point(668, 1607);
		    Sequence tap2 = new Sequence(finger2, 1);
		    tap2.addAction(finger2.createPointerMove(Duration.ofMillis(0),
		        PointerInput.Origin.viewport(), tapPoint2.x, tapPoint2.y));
		    tap2.addAction(finger2.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		    tap2.addAction(new Pause(finger2, Duration.ofMillis(50)));
		    tap2.addAction(finger2.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		    driver.perform(Arrays.asList(tap2));
		    
		    driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@resource-id=\"com.airbnb.android:id/stays_when_panel_compose\"]/android.view.View/android.view.View/android.view.View[4]/android.widget.Button")).click();
		    driver.findElement(AppiumBy.xpath("(//android.widget.Button[@content-desc=\"incrementa\"])[1]")).click();
		    driver.findElement(AppiumBy.xpath("(//android.widget.Button[@content-desc=\"incrementa\"])[2]")).click();
		    driver.findElement(AppiumBy.id("com.airbnb.android:id/n2_dls_action_footer_gradient_button")).click();
		    
		    PointerInput finger3 = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		    Point start = new Point(962, 1786);
		    Point end = new Point (958, 866);
		    Sequence swipe = new Sequence(finger, 1);
		    swipe.addAction(finger3.createPointerMove(Duration.ofMillis(0),
		        PointerInput.Origin.viewport(), start.getX(), start.getY()));
		    swipe.addAction(finger3.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		    swipe.addAction(finger3.createPointerMove(Duration.ofMillis(1000),
		        PointerInput.Origin.viewport(), end.getX(), end.getY()));
		    swipe.addAction(finger3.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		    driver.perform(Arrays.asList(swipe));
		      
		    driver.findElement(AppiumBy.xpath("(//android.widget.ImageView[@resource-id=\"com.airbnb.android:id/photo\"])[2]")).click();
		    driver.findElement(AppiumBy.id("com.airbnb.android:id/n2_dls_action_footer_gradient_button")).click();

		    PointerInput finger4 = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		    Point start2 = new Point(640, 1975);
		    Point end2 = new Point (654, 576);
		    Sequence swipe2 = new Sequence(finger4, 1);
		    swipe2.addAction(finger4.createPointerMove(Duration.ofMillis(0),
		        PointerInput.Origin.viewport(), start2.getX(), start2.getY()));
		    swipe2.addAction(finger4.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		    swipe2.addAction(finger4.createPointerMove(Duration.ofMillis(1000),
		        PointerInput.Origin.viewport(), end2.getX(), end2.getY()));
		    swipe2.addAction(finger4.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		    driver.perform(Arrays.asList(swipe2));
		      
		    driver.findElement(AppiumBy.accessibilityId("Agregar forma de pago")).click();
		    driver.findElement(AppiumBy.xpath("//androidx.recyclerview.widget.RecyclerView[@resource-id=\"com.airbnb.android:id/recycler_view\"]/android.widget.FrameLayout[3]")).click();
		    driver.findElement(AppiumBy.xpath("//android.widget.EditText[@resource-id=\"com.airbnb.android:id/edit_text\" and @text=\"Número de la tarjeta\"]")).sendKeys("11112222333344444");
		    driver.findElement(AppiumBy.xpath("//android.widget.EditText[@resource-id=\"com.airbnb.android:id/edit_text\" and @text=\"Vencimiento\"]")).sendKeys("05/29");
		    driver.findElement(AppiumBy.xpath("//android.widget.EditText[@resource-id=\"com.airbnb.android:id/edit_text\" and @text=\"Código CVV\"]")).sendKeys("456");
		    driver.findElement(AppiumBy.id("com.airbnb.android:id/footer_button")).click();
		   
    }

}
